package pageranking;

import java.util.ArrayList;
import java.util.List;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;

public class SimplePageRanking{

	private final String nodeAttributePageRank = "page_rank";
	private double dampingFactor;
	private double precision;
	private Graph graph;
	private double normDiff;
	private List<Double> newRanks;
	private int iterationCount;
	private ElemenetSinkImpl elementSink;

	public SimplePageRanking(Graph graph, double dampingFactor, Double precision,ElemenetSinkImpl sink) {
		this.dampingFactor = dampingFactor;
		this.precision = precision;
		this.graph = graph;
		double initialRank = 1.0 / graph.getNodeCount();
		graph.nodes().forEach(node -> node.setAttribute(nodeAttributePageRank, initialRank));
		newRanks = new ArrayList<Double>(graph.getNodeCount());
		iterationCount = 0;
		this.elementSink = sink;
		elementSink.setGraphChanged(true);
	}

	private void compute() {
		if (!elementSink.isGraphChanged())
			return;
		do {
			iteration();
			System.out.println("norm difference - " +String.format("%6d%16.8f%n",iterationCount,normDiff));
		} while (normDiff > precision);
		elementSink.setGraphChanged(false);
	}
	
	private void iteration() {
		double dampingTerm = (1 - dampingFactor) / graph.getNodeCount();
		newRanks.clear();
		double danglingRank = 0;
		for (int i = 0; i < graph.getNodeCount(); i++) {
			Node node = graph.getNode(i);
			double sum = 0;
			for (int j = 0; j < node.getInDegree(); j++) {
				Node other = node.getEnteringEdge(j).getOpposite(node);
				sum += other.getNumber(nodeAttributePageRank) / other.getOutDegree();
			}
			newRanks.add(dampingTerm + dampingFactor * sum);
			if (node.getOutDegree() == 0)
				danglingRank += node.getNumber(nodeAttributePageRank);
		}
		danglingRank *= dampingFactor / graph.getNodeCount();

		normDiff = 0;
		for (int i = 0; i < graph.getNodeCount(); i++) {
			Node node = graph.getNode(i);
			double currentRank = node.getNumber(nodeAttributePageRank);
			double newRank = newRanks.get(i) + danglingRank;
			normDiff += Math.abs(newRank - currentRank);
			node.setAttribute(nodeAttributePageRank, newRank);
		}
		iterationCount++;
		System.out.println("iteration "+iterationCount+",newRanks:"+ newRanks.size()+", newRanks:"+ newRanks);
	}
	
	public double getRank(Node node) {
		compute();
		return node.getNumber(nodeAttributePageRank);
	}
}