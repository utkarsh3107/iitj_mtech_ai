package pageranking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.stream.Collectors;

import org.graphstream.algorithm.generator.DorogovtsevMendesGenerator;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;


public class SimplePageRankingDemo {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("org.graphstream.ui","swing");
		Graph graph = new SingleGraph("simple_page_ranking_graph");
		graph.setAttribute("ui.antialias", true);
		graph.setAttribute("ui.stylesheet", "node {fill-color: blue; size-mode: dyn-size;} edge {fill-color:red;}");
		
		DorogovtsevMendesGenerator generator = new DorogovtsevMendesGenerator();
		generator.setDirectedEdges(true, true);
		ElemenetSinkImpl sinkSource = new ElemenetSinkImpl(graph);
		graph.addElementSink(sinkSource);
		generator.addSink(graph);
		SimplePageRanking pageRank = new SimplePageRanking(graph, 0.85, 1.0e-5,sinkSource);
		generator.begin();

		while (graph.getNodeCount() < 100) {
			generator.nextEvents();
		}
		generator.end();

		System.out.println("GENERATED GRAPH");
		System.out.println("-----------------");
		graph.forEach(each -> {
			System.out.println(each +" -- "+each.edges().collect(Collectors.toSet()));
		});
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("waiting for input...");
		reader.readLine();
		DecimalFormat format = new DecimalFormat("#.########");
		
		for (Node node : graph) {
			double rank = pageRank.getRank(node);
			//node.setAttribute("ui.size", 5 + Math.sqrt(graph.getNodeCount() * rank * 500));
			node.setAttribute("ui.size", 50);
			node.setAttribute("ui.label", format.format(rank * 100));
		}
		graph.display(true);
	}
}