- Change Week-XX.tex to Week-01.tex, Week-02.tex, ..., etc
- Change gta-lecture.tex accordingly. 
- Run: pdflatex gta-lecture.tex

