In this data set, we only contain the network files we obtained in jdk and junit4.

The whole data set will be published after the acceptance of our paper via the same url as shown in the paper.

When using ElementRank software to analyze our data set, please do not change the name of the .net files.

The .net file has the following format:
Node count: *Vertices count

Node List:
    number "node name"
EX:   1    "org.apache.tools.ant.taskdefs.optional.sitraka"

Arc List:
node1 node2 weight
EX: 1 2 3
Meaning: from node 1 to node 2 with weight 3
