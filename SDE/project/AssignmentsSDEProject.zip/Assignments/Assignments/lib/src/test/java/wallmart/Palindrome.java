package wallmart;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class Palindrome {


    public static void main(String[] args){
        String input = "aaabc";

        Map<Character,Integer> map = new HashMap<>();



    }

}
