package sde.elementrank.original;

import java.awt.BorderLayout;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JTableResultShow  extends JTable{
	private static DefaultTableModel a = null;
	  
	  private static JTable b = null;
	  
	  public static void a(String[] paramArrayOfString) {
	    Vector<String> vector = new Vector();
	    String[] arrayOfString;
	    int i = (arrayOfString = paramArrayOfString).length;
	    for (byte b = 0; b < i; b++) {
	      String str = arrayOfString[b];
	      vector.addElement(str);
	    } 
	    a.addRow(vector);
	  }
	  
	  private static void b(String[] paramArrayOfString) {
	    DefaultTableModel defaultTableModel = new DefaultTableModel();
	    for (byte b = 0; b < paramArrayOfString.length; b++)
	      defaultTableModel.addColumn(paramArrayOfString[b]); 
	    a = defaultTableModel;
	  }
	  
	  public static void a(String paramString, String[] paramArrayOfString) {
	    JFrame jFrame;
	    (jFrame = new JFrame()).setTitle(paramString);
	    jFrame.getContentPane().setLayout(new BorderLayout());
	    b(paramArrayOfString);
	    (b = new JTable()).setModel(a);
	    JScrollPane jScrollPane = new JScrollPane(b);
	    jFrame.getContentPane().add(jScrollPane, "Center");
	    jFrame.setSize(600, 200);
	    jFrame.setLocation(250, 250);
	    jFrame.setVisible(true);
	  }
	  
	  public static void main(String[] paramArrayOfString) {
	    a("Node Degree", paramArrayOfString);
	    (paramArrayOfString = new String[3])[0] = "1";
	    paramArrayOfString[1] = "2";
	    paramArrayOfString[2] = "3";
	    a(paramArrayOfString);
	  }
}