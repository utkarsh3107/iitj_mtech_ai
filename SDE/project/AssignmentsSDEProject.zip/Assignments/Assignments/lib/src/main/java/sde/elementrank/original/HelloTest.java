package sde.elementrank.original;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class HelloTest {
	public static void main(String args[]) throws IOException {
		Files.walk(Paths.get("D:\\workspace\\projects\\ElementRank_TSE2019\\ElementRank\\data set"))
    	.filter(Files::isRegularFile)
    	.filter(each->each.toAbsolutePath().toString().endsWith(".net"))
    	.forEach(each -> {
    		System.out.println(each.toFile().getAbsolutePath());	
    	});
	}
}