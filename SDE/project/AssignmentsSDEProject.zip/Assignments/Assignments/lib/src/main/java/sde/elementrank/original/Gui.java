package sde.elementrank.original;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Calendar;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import sde.elementrank.original.WeightedPageRank4PackRank_wfpan_all4one;

public class Gui extends JFrame implements ActionListener{
	 private JFrame a;
	  
	  private JLabel b;
	  
	  private static JTextArea c;
	  
	  private String d = null;
	  
	  private Calendar e = Calendar.getInstance();
	  
	  private static File f;
	  
	  private void a() {
	    this.e = Calendar.getInstance();
	    this.d = String.valueOf(this.e.get(11)) + ":" + this.e.get(12) + ":" + this.e.get(13);
	    c.append("\n" + this.d);
	    c.append("\n");
	  }
	  
	  public Gui() {
	    this.d = String.valueOf(this.e.get(11)) + ":" + this.e.get(12) + ":" + this.e.get(13);
	    this.a = new JFrame("ElementRank: Ranking Java Software Classes and Packages using a Multilayer Complex Network-Based Approach");
	    this.b = new JLabel("NONE");
	    JPanel jPanel = new JPanel();
	    (c = new JTextArea(this.d)).append("\n");
	    c.append("Welcome to use the software for ElementRank\nCopyright (C) 2008-2019 by Weifeng Pan\nSchool of Computer Science and Infromation Engineering, Zhejiang Gongshang University wfpan@mail.zjgsu.edu.cn\nHo to use:\nStep 1: File -> Choose the Directory.\nStep 2: Analysis -> Aggregated Weighted PageRank to compute the global weighted PR values.");
	    c.setSize(new Dimension(50, 50));
	    JScrollPane jScrollPane = new JScrollPane(c);
	    jPanel.setLayout(new BorderLayout());
	    JMenuBar jMenuBar = new JMenuBar();
	    JMenu jMenu1 = new JMenu("File");
	    JMenu jMenu2 = new JMenu("Analysis");
	    JMenu jMenu3 = new JMenu("Help");
	    jMenuBar.add(jMenu1);
	    jMenuBar.add(jMenu2);
	    jMenuBar.add(jMenu3);
	    JMenuItem jMenuItem1;
	    (jMenuItem1 = new JMenuItem("Open Directory...")).addActionListener(this);
	    JMenuItem jMenuItem2;
	    (jMenuItem2 = new JMenuItem("Exit")).addActionListener(this);
	    JMenuItem jMenuItem3;
	    (jMenuItem3 = new JMenuItem("Aggregated Weighted PageRank")).addActionListener(this);
	    jMenu2.add(jMenuItem3);
	    jMenu1.add(jMenuItem1);
	    jMenu1.addSeparator();
	    jMenu1.add(jMenuItem2);
	    this.a.setJMenuBar(jMenuBar);
	    jPanel.add(jScrollPane);
	    jPanel.add(this.b, "South");
	    this.a.setJMenuBar(jMenuBar);
	    this.a.add(jPanel);
	    this.a.setDefaultCloseOperation(2);
	    this.a.setVisible(true);
	    this.a.setSize(700, 400);
	    this.a.setLocationRelativeTo((Component)null);
	  }
	  
	  public void actionPerformed(ActionEvent paramActionEvent) {
	    if (paramActionEvent.getActionCommand().equals("Open Directory...")) {
	      JFileChooser jFileChooser;
	      (jFileChooser = new JFileChooser(System.getProperty("user.dir"))).setFileSelectionMode(1);
	      int i;
	      if ((i = jFileChooser.showOpenDialog(null)) == 0) {
	        String str = jFileChooser.getSelectedFile().getAbsolutePath();
	        f = new File(str);
	        this.b.setText("You Choose the directory:".concat(String.valueOf(str)));
	      } 
	      if (i == 1)
	        this.b.setText("NONE"); 
	    } 
	    if (paramActionEvent.getActionCommand().equals("Exit"))
	      System.exit(0); 
	    if (paramActionEvent.getActionCommand().equals("Aggregated Weighted PageRank")) {
	      if (f != null) {
	        a();
	        c.append("Computing the Aggregated Weighted PageRank values\n");
	        String str = f.getAbsolutePath();
	        WeightedPageRank4PackRank_wfpan_all4one.main(new String[] { str });
	        a();
	        c.append("Weighted PageRank computation finishes. \nPlease see the results in " + f.getAbsolutePath() + ". Results are in the file whose name ends with _WPR.txt\n");
	        return;
	      } 
	      a();
	      c.append("Warning: Please use File->Open Directory first\n");
	    } 
	  }
	  
	  public static void main(String[] paramArrayOfString) {
		  Gui gui = new Gui();
		  gui.show();
	  }
}