package sde.elementrank.original;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class WeightedPageRank4PackRank_wfpan_all4one {

	private static int a;

	private static int b;

	private static float[] c = null;

	private static float a(String paramString) {
		return (paramString = paramString.substring(paramString.lastIndexOf("\\") + 1)).startsWith("1CALLS") ? 0.034F : (paramString.startsWith("1EXTENDS") ? 0.29F : (paramString.startsWith("1FUNC_PARAM") ? 0.034F : (paramString.startsWith("1FUNC_RET") ? 0.034F : (paramString.startsWith("1GLOBAL_VAR") ? 0.178F : (paramString.startsWith("1IMPLEMENTS") ? 0.394F : (paramString.startsWith("1LOCAL_VAR") ? 0.034F : 0.0F))))));
	}

	private static void computeElementRank(String fieName, String outputFileName, String[] paramArrayOfString) throws IOException {
		BufferedWriter bufferedWriter = null;
		boolean bool = true;
		float f1 = 0.0F;
		int b1 = 1;
		String str2 = fieName;
		File file = new File(str2);
		FileReader fileReader = new FileReader(file);
		int i;
		String[] arrayOfString1;
		String str1;
		BufferedReader bufferedReader;
		float[][] arrayOfFloat = new float[i = Integer.parseInt((arrayOfString1 = (str1 = (bufferedReader = new BufferedReader(fileReader)).readLine()).split(" "))[1])][i];
		float[] arrayOfFloat1 = new float[i];
		float[] arrayOfFloat2 = new float[i];
		float f2 = 0.0F;
		float[] arrayOfFloat3 = new float[i];
		float[] arrayOfFloat4 = new float[i];
		if (b == a)
			c = new float[i]; 
		float f3 = 0.0F;
		int b2 = 1;
		int b3 = 0;
		String[] arrayOfString2 = new String[i];
		while (b2==1) {
			String str3;
			if ((str3 = bufferedReader.readLine()).equals("*Arcs")) {
				b2 = 0;
				continue;
			} 
			if (str3.equals("*Edges"))
				System.exit(0); 
			String str4 = str3.substring(str3.indexOf("\"") + 1, str3.lastIndexOf("\""));
			arrayOfString2[b3] = str4;
			b3++;
		} 
		float[] arrayOfFloat5 = new float[i];
		int b4;
		for (b4 = 0; b4 < i; b4++)
			arrayOfFloat5[b4] = 1.0F / i; 
		while (b1==1) {
			String str;
			if ((str = bufferedReader.readLine()) == null) {
				b1 = 0;
				continue;
			} 
			String[] arrayOfString = str.split(" ");
			if (3 == arrayOfString.length) {
				arrayOfFloat[(new Integer(arrayOfString[0])).intValue() - 1][(new Integer(arrayOfString[1])).intValue() - 1] = Float.parseFloat(arrayOfString[2]);
				continue;
			} 
			if (2 == arrayOfString.length)
				System.exit(0); 
		} 
		bufferedReader.close();
		fileReader.close();
		for (b4 = 0; b4 < i; b4++) {
			float f5 = 0.0F;
			float f4 = 0.0F;
			for (int b = 0; b < i; b++) {
				if (Math.abs(arrayOfFloat[b4][b]) >= 1.0E-7D)
					f5 += arrayOfFloat[b4][b]; 
				if (Math.abs(arrayOfFloat[b][b4]) >= 1.0E-7D)
					f4 += arrayOfFloat[b][b4]; 
			} 
			arrayOfFloat1[b4] = f5;
			arrayOfFloat2[b4] = f4;
			f2 += arrayOfFloat2[b4];
		} 
		System.out.println("");
		b4 = 0;

		//Actual algorithm implementation
		//d = 0.85; 5; sumwInLinks = 0; sum = 0; SqDev =0; sigma = 10e-6
		while (true) {
			for (b2 = 0; b2 < i; b2++)
				arrayOfFloat3[b2] = arrayOfFloat5[b2]; 
			for (b1 = 0; b1 < i; b1++) {
				for (int b = 0; b < i; b++) {
					float f;
					if (Math.abs(f = arrayOfFloat[b][b1]) >= 1.0E-7D)
						f1 += arrayOfFloat3[b] * arrayOfFloat[b][b1] / arrayOfFloat1[b]; 
				} 
				f1 = f1 * 0.85F + 0.15F * arrayOfFloat2[b1] / f2;
				f3 += (f1 - arrayOfFloat4[b1]) * (f1 - arrayOfFloat4[b1]);
				arrayOfFloat4[b1] = f1;
				arrayOfFloat5[b1] = f1;
				f1 = 0.0F;
			} 
			if (Math.sqrt(f3) - 1.0E-13D < 0.0D || b4 + 1 > 10000) {
				System.out.println("==========================================================");
				for (b1 = 0; b1 < i; b1++) {
					c[b1] = c[b1] + a(fieName) * arrayOfFloat4[b1];
					String str;
					System.out.println("abcdef: " +String.valueOf((str = (str = fieName).substring(str.lastIndexOf("\\") + 1)).startsWith("1CALLS") ? "MCR" : (str.startsWith("1EXTENDS") ? "INR" : (str.startsWith("1FUNC_PARAM") ? "PAR" : (str.startsWith("1FUNC_RET") ? "RTR" : (str.startsWith("1GLOBAL_VAR") ? "GVR" : (str.startsWith("1IMPLEMENTS") ? "IMR" : (str.startsWith("1LOCAL_VAR") ? "LVR" : "ERROR"))))))) + "=" + a(fieName) + "*" + arrayOfFloat4[b1]);
					if (a == 1 && bool) {
						String outFile = String.valueOf(outputFileName.substring(0, outputFileName.lastIndexOf("."))) + "GlobalWeightedPR.txt";
						System.out.println("outFile :"+outFile);
						bufferedWriter = new BufferedWriter(new FileWriter(new File(outFile)));
						bool = false;
					} 
					if (a == 1) {
						paramArrayOfString[0] = (new StringBuilder(String.valueOf(b1 + 1))).toString();
						paramArrayOfString[1] = (new StringBuilder(String.valueOf(arrayOfString2[b1]))).toString();
						paramArrayOfString[2] = Double.toString(c[b1]);
						JTableResultShow.a(paramArrayOfString);
						bufferedWriter.write(String.valueOf(arrayOfString2[b1]) + "\t" + c[b1]);
						bufferedWriter.newLine();
					} 
				} 
				a--;
			} else {
				f3 = 0.0F;
				b4++;
				continue;
			} 
			if (bufferedWriter != null) {
				bufferedWriter.flush();
				bufferedWriter.close();
			} 
			return;
		} 
	}

	private static List<String> prepareFilesList(String filePath, String fileExtension) throws IOException {
		ArrayList<String> arrayList = new ArrayList<>();

		/* validation */	   
		if(Objects.isNull(filePath)|| "".equalsIgnoreCase(filePath)) {
			System.out.println("file path null or empty is not allowed.");
			return arrayList;
		}

		if(Objects.isNull(fileExtension)|| "".equalsIgnoreCase(fileExtension)) {
			System.out.println("file extension null or empty is not allowed.");
			return arrayList;
		}

		if(!".net".equalsIgnoreCase(fileExtension)) {
			System.out.println("file "+ fileExtension +" is not allowed.");
			return arrayList;
		}

		Path path = Paths.get(filePath);

		if(!Files.exists(path, LinkOption.NOFOLLOW_LINKS)|| 
				!Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
			System.out.println("directory not found.");
			return arrayList;
		}

		//Recursively add file paths into the list
		Files.walk(path)
		.filter(Files::isRegularFile)
		.filter(each->each.toAbsolutePath().toString().endsWith(fileExtension))
		.forEach(each -> {
			arrayList.add(each.toFile().getAbsolutePath());	
		});
		return arrayList;
	}

	public static void main(String[] args) {
		try {
			Instant now = Instant.now();
			String[] arrayOfString1 = new String[3];
			String[] arrayOfString2 = { "id", "name", "Global Weighted PageRank" };
			JTableResultShow.a("Aggregated PageRank values", arrayOfString2);
			String filePath = "C:\\Users\\bojjam\\Downloads\\Assignments\\Assignments\\lib\\data set\\jdk_MPN";
			List<String> list = prepareFilesList(filePath, ".net");
			a = list.size();
			b = list.size();
			for (String fileName : list) {
				String outputFileName = String.valueOf(fileName.substring(0, fileName.lastIndexOf("."))) + "_OUTPUT.txt";
				try {
					computeElementRank(fileName, outputFileName, arrayOfString1);
				} catch (Exception exception) {
					exception.printStackTrace();
				} 
			} 
			System.out.println("elapsed time in seconds: "+Duration.between(now, Instant.now()).toSeconds());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}